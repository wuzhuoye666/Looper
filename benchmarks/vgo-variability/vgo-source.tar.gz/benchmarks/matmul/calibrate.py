#!/usr/bin/env python3
"""Choose a safe Matmul dimension for a resource-constrained VGO target.

It bounds the estimated working set to a configurable fraction of currently
available memory, then measures candidate sizes until the multiplication kernel
falls in the requested time band.  The resulting JSON is immutable input evidence
for a VGO experiment; delete nothing and calibrate again on a different host.
"""

from __future__ import annotations

import argparse
import json
import math
import os
from pathlib import Path
import platform
import re
import subprocess
import sys
from datetime import datetime, timezone
from statistics import median
from typing import Any


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def load_env_file(path: Path) -> dict[str, str]:
    values: dict[str, str] = {}
    if not path.is_file():
        return values
    for line in path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        value = value.strip()
        if len(value) >= 2 and value[0] == value[-1] and value[0] in {"'", '"'}:
            value = value[1:-1]
        values[key.strip()] = value
    for key, value in os.environ.items():
        if key.startswith("VGO_MATMUL_"):
            values[key] = value
    return values


def memory_available_bytes() -> int:
    values: dict[str, int] = {}
    try:
        for line in Path("/proc/meminfo").read_text(encoding="ascii").splitlines():
            match = re.match(r"^(\w+):\s+(\d+)\s+kB$", line)
            if match:
                values[match.group(1)] = int(match.group(2)) * 1024
    except OSError:
        return 0
    available = values.get("MemAvailable", values.get("MemFree", 0))
    # Respect a cgroup v2 or v1 memory limit when a VM/container exposes one.
    for path in (Path("/sys/fs/cgroup/memory.max"), Path("/sys/fs/cgroup/memory/memory.limit_in_bytes")):
        try:
            raw = path.read_text(encoding="ascii").strip()
            if raw and raw != "max":
                limit = int(raw)
                if 0 < limit < 1 << 60:
                    available = min(available, limit)
        except (OSError, ValueError):
            continue
    return available


def estimated_peak_bytes(dimension: int, itemsize: int) -> int:
    # Input + output + conservative BLAS/temporary allowance.  The source matrix
    # is intentionally used twice, so it is not two independently allocated inputs.
    return int(dimension * dimension * itemsize * 3.0)


def measure_candidate(
    python: str,
    benchmark: Path,
    dimension: int,
    dtype: str,
    trials: int,
    environment: dict[str, str],
) -> dict[str, Any]:
    values: list[float] = []
    errors: list[str] = []
    for trial in range(1, trials + 1):
        command = [python, str(benchmark), "--dimension", str(dimension), "--dtype", dtype]
        try:
            result = subprocess.run(
                command,
                cwd=str(benchmark.parent),
                env=environment,
                text=True,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                timeout=45,
                check=False,
            )
        except subprocess.TimeoutExpired:
            errors.append(f"trial {trial}: timeout after 45 seconds")
            continue
        match = re.search(r"(?m)^Compute:\s*([0-9]+(?:\.[0-9]+)?)", result.stdout)
        if result.returncode != 0 or match is None or "VGO_MATMUL_OK" not in result.stdout:
            errors.append(
                f"trial {trial}: exit={result.returncode}; "
                f"stdout={result.stdout[-240:]!r}; stderr={result.stderr[-240:]!r}"
            )
            continue
        values.append(float(match.group(1)))
    return {
        "dimension": dimension,
        "n_success": len(values),
        "compute_times_s": values,
        "median_s": float(median(values)) if values else math.nan,
        "errors": errors,
    }


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=Path(__file__).resolve().parents[2])
    parser.add_argument("--reuse", action="store_true", help="Reuse a same-host existing calibration.")
    parser.add_argument("--trials", type=int, default=3)
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    if args.trials <= 0:
        raise SystemExit("--trials must be positive")
    root = args.root.resolve()
    config = load_env_file(root / "config" / "experiment.env")
    output = root / "config" / "matmul_calibration.json"
    if args.reuse and output.is_file():
        existing = json.loads(output.read_text(encoding="utf-8"))
        if existing.get("host") == platform.node() and int(existing.get("dimension", 0)) > 0:
            print(f"matmul_calibration=reused ({output})")
            return 0

    dtype = config.get("VGO_MATMUL_DTYPE", "float32")
    itemsize = 4 if dtype == "float32" else 8
    fraction = float(config.get("VGO_MATMUL_MEMORY_FRACTION", "0.55"))
    min_seconds = float(config.get("VGO_MATMUL_MIN_RUNTIME_S", "0.20"))
    max_seconds = float(config.get("VGO_MATMUL_MAX_RUNTIME_S", "5.00"))
    max_dimension = int(config.get("VGO_MATMUL_MAX_DIM", "4096"))
    threads = int(config.get("VGO_MATMUL_THREADS", "1"))
    if not (0.05 <= fraction <= 0.80):
        raise SystemExit("VGO_MATMUL_MEMORY_FRACTION must be within [0.05, 0.80]")
    if not (0 < min_seconds <= max_seconds):
        raise SystemExit("Matmul calibration time range is invalid")

    available = memory_available_bytes()
    budget = int(available * fraction)
    if budget <= 0:
        raise SystemExit("Cannot read available memory; do not guess a Matmul size")
    benchmark = root / "benchmarks" / "matmul" / "benchmark.py"
    if not benchmark.is_file():
        raise SystemExit(f"Missing benchmark: {benchmark}")
    candidates = [256, 384, 512, 768, 1024, 1536, 2048, 2560, 3072, 3584, 4096, 4608, 5120]
    candidates = [
        candidate
        for candidate in candidates
        if candidate <= max_dimension and estimated_peak_bytes(candidate, itemsize) <= budget
    ]
    if not candidates:
        raise SystemExit("No Matmul candidate fits the configured memory budget")

    environment = dict(os.environ)
    for variable in ("OPENBLAS_NUM_THREADS", "OMP_NUM_THREADS", "MKL_NUM_THREADS", "BLIS_NUM_THREADS", "NUMEXPR_NUM_THREADS"):
        environment[variable] = str(threads)
    environment["PYTHONHASHSEED"] = "0"

    trials: list[dict[str, Any]] = []
    selected: dict[str, Any] | None = None
    previous: dict[str, Any] | None = None
    selection_reason = ""
    for dimension in candidates:
        record = measure_candidate(sys.executable, benchmark, dimension, dtype, args.trials, environment)
        record["estimated_peak_bytes"] = estimated_peak_bytes(dimension, itemsize)
        trials.append(record)
        current = record["median_s"]
        if not math.isfinite(current):
            continue
        if current > max_seconds:
            selected = previous or record
            selection_reason = "previous_size_within_runtime_band" if previous else "smallest_candidate_exceeded_upper_runtime_bound"
            break
        previous = record
        if current >= min_seconds:
            selected = record
            selection_reason = "first_candidate_in_target_runtime_band"
            break
    if selected is None:
        selected = previous
        selection_reason = "largest_safe_candidate_below_target_runtime"
    if selected is None:
        raise SystemExit("All safe Matmul calibration trials failed; preserve their output and inspect NumPy/BLAS")

    payload = {
        "schema_version": 1,
        "created_at": utc_now(),
        "host": platform.node(),
        "python": sys.executable,
        "dtype": dtype,
        "threads": threads,
        "dimension": int(selected["dimension"]),
        "median_compute_s": selected["median_s"],
        "estimated_peak_bytes": int(selected["estimated_peak_bytes"]),
        "available_memory_bytes": available,
        "memory_budget_bytes": budget,
        "memory_fraction": fraction,
        "target_runtime_seconds": {"min": min_seconds, "max": max_seconds},
        "selection_reason": selection_reason,
        "trials": trials,
    }
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(f"matmul_calibration={output}")
    print(
        f"dimension={payload['dimension']} median_compute_s={payload['median_compute_s']:.6f} "
        f"estimated_peak_gib={payload['estimated_peak_bytes'] / 1024**3:.3f}"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
