#!/usr/bin/env python3
"""One deterministic NumPy matrix-multiplication observation for VGO.

The process performs allocation before the timed kernel so the application metric
is the multiplication itself.  The outer VGO runner separately records end-to-end
wall time, process statistics, and (when requested) perf counters.
"""

from __future__ import annotations

import argparse
import math
import os
import time

import numpy as np


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--dimension", type=int, required=True)
    parser.add_argument("--dtype", choices=("float32", "float64"), default="float32")
    parser.add_argument("--seed", type=int, default=2026)
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    if args.dimension < 16:
        raise SystemExit("dimension must be at least 16")
    dtype = np.dtype(args.dtype)
    generator = np.random.default_rng(args.seed)
    matrix = generator.standard_normal((args.dimension, args.dimension), dtype=dtype)

    start = time.perf_counter()
    product = matrix @ matrix
    compute_time = time.perf_counter() - start
    # Touch a deterministic, tiny portion of the result so a future implementation
    # cannot silently replace the multiplication with an unevaluated expression.
    checksum = float(product[0, 0] + product[-1, -1] + product[args.dimension // 2, args.dimension // 2])
    if not math.isfinite(checksum):
        print("VGO_MATMUL_FAILED non-finite result", flush=True)
        return 2
    print(
        "VGO_MATMUL_OK "
        f"dimension={args.dimension} dtype={dtype.name} "
        f"threads={os.environ.get('OPENBLAS_NUM_THREADS', 'uncontrolled')} "
        f"checksum={checksum:.9g}",
        flush=True,
    )
    print(f"Compute: {compute_time:.9f}", flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
