#!/usr/bin/env bash
set -Eeuo pipefail

SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd -P)"

if ! command -v python3 >/dev/null 2>&1; then
  printf 'ERROR: Python 3 is unavailable; Phase 0 cannot write the required JSON report.\n' >&2
  exit 1
fi

exec python3 "$SCRIPT_DIR/check_environment.py" "$@"
