#!/usr/bin/env python3
"""Run the read-only Phase 0 feasibility check for the VGO reproduction.

This script intentionally does not install packages or change kernel settings.  It
records what the target Linux machine exposes *before* any benchmark preparation,
including per-event ``perf`` capability.  The later runner is responsible for
temporary THP changes and restoring them afterwards.
"""

from __future__ import annotations

import argparse
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
from datetime import datetime, timezone
from typing import Any


PERF_EVENTS = (
    "task-clock",
    "context-switches",
    "cpu-migrations",
    "page-faults",
    "cycles",
    "instructions",
    "cache-references",
    "cache-misses",
    "dTLB-loads",
    "dTLB-load-misses",
    "branch-misses",
    "LLC-load-misses",
)
SOFTWARE_EVENTS = {"task-clock", "context-switches", "cpu-migrations", "page-faults"}
HARDWARE_EVENTS = set(PERF_EVENTS) - SOFTWARE_EVENTS
THP_FILE = Path("/sys/kernel/mm/transparent_hugepage/enabled")
THP_DEFRAG_FILE = Path("/sys/kernel/mm/transparent_hugepage/defrag")


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def run_text(command: list[str], timeout: float = 15.0) -> tuple[int, str]:
    """Run a read-only command and retain stdout/stderr as evidence."""

    environment = dict(os.environ)
    environment.update({"LC_ALL": "C", "LANG": "C"})
    try:
        completed = subprocess.run(
            command,
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            timeout=timeout,
            check=False,
            env=environment,
        )
    except FileNotFoundError:
        return 127, f"command not found: {command[0]}"
    except subprocess.TimeoutExpired:
        return 124, f"command timed out after {timeout:.1f}s: {' '.join(command)}"
    text = "\n".join(part for part in (completed.stdout.strip(), completed.stderr.strip()) if part)
    return completed.returncode, text


def read_text(path: Path) -> str:
    try:
        return path.read_text(encoding="utf-8", errors="replace").strip()
    except OSError:
        return ""


def first_line(text: str, fallback: str = "unavailable") -> str:
    for line in text.splitlines():
        if line.strip():
            return line.strip()
    return fallback


def parse_key_value_lines(text: str) -> dict[str, str]:
    values: dict[str, str] = {}
    for line in text.splitlines():
        if ":" not in line:
            continue
        key, value = line.split(":", 1)
        values[key.strip()] = value.strip()
    return values


def meminfo() -> dict[str, int]:
    values: dict[str, int] = {}
    for line in read_text(Path("/proc/meminfo")).splitlines():
        match = re.match(r"^(\w+):\s+(\d+)\s+kB$", line)
        if match:
            values[match.group(1)] = int(match.group(2)) * 1024
    return values


def visible_numa_nodes() -> int:
    code, output = run_text(["lscpu", "-p=NODE"])
    if code == 0:
        nodes = {line.strip() for line in output.splitlines() if line.strip() and not line.startswith("#")}
        if nodes:
            return len(nodes)
    code, output = run_text(["numactl", "--hardware"])
    match = re.search(r"available:\s*(\d+)\s+nodes", output)
    return int(match.group(1)) if match else 0


def current_thp_mode(path: Path) -> str:
    text = read_text(path)
    match = re.search(r"\[([^]]+)\]", text)
    return match.group(1) if match else ("unavailable" if not text else "unknown")


def cpu_governors() -> list[str]:
    root = Path("/sys/devices/system/cpu")
    return sorted(
        {
            read_text(path)
            for path in root.glob("cpu[0-9]*/cpufreq/scaling_governor")
            if read_text(path)
        }
    )


def virtualization(lscpu_data: dict[str, str]) -> tuple[bool, str]:
    code, output = run_text(["systemd-detect-virt"])
    detected = first_line(output, "unknown") if code == 0 else "unknown"
    hypervisor = lscpu_data.get("Hypervisor vendor", "")
    if detected and detected not in {"none", "unknown", "unavailable"}:
        return True, hypervisor or detected
    if hypervisor:
        return True, hypervisor
    cpuinfo = read_text(Path("/proc/cpuinfo")).lower()
    return ("hypervisor" in cpuinfo), ("flag only" if "hypervisor" in cpuinfo else "none")


def has_numpy() -> bool:
    code, _ = run_text(["python3", "-c", "import numpy; print(numpy.__version__)"], timeout=10)
    return code == 0


def reason_for_perf_failure(text: str, returncode: int) -> str:
    normalized = text.lower()
    if "permission" in normalized or "access denied" in normalized or "paranoid" in normalized:
        return "permission_denied"
    if "not supported" in normalized or "unknown event" in normalized or "no such event" in normalized:
        return "not_supported"
    if "not counted" in normalized:
        return "not_counted"
    if returncode == 127:
        return "perf_not_installed"
    if returncode == 124:
        return "perf_test_timeout"
    return "perf_command_failed"


def perf_event_result(event: str, sudo_available: bool) -> dict[str, Any]:
    perf = shutil.which("perf")
    if perf is None:
        return {
            "event": event,
            "supported": False,
            "collector": "none",
            "reason": "perf_not_installed",
            "detail": "perf command not found",
        }

    base = [perf, "stat", "-x", ",", "--no-big-num", "-e", event, "--", "sleep", "0.25"]
    for collector, command in (
        ("unprivileged", base),
        ("sudo", ["sudo", "-n", *base]) if sudo_available else ("skip", []),
    ):
        if collector == "skip":
            continue
        returncode, output = run_text(command, timeout=10)
        normalized = output.lower()
        unsupported_marker = any(
            marker in normalized
            for marker in ("not supported", "not counted", "permission denied", "access denied")
        )
        if returncode == 0 and not unsupported_marker:
            return {
                "event": event,
                "supported": True,
                "collector": collector,
                "reason": "",
                "detail": output[-1200:],
            }
        last = {
            "event": event,
            "supported": False,
            "collector": collector,
            "reason": reason_for_perf_failure(output, returncode),
            "detail": output[-1200:],
        }
    return last


def readiness(
    cpu_count: int,
    memory_bytes: int,
    numa_nodes: int,
    supported_events: set[str],
    thp_readable: bool,
    sudo_available: bool,
    numpy_available: bool,
) -> dict[str, dict[str, str]]:
    basic_cpu = cpu_count >= 2 and memory_bytes >= 4 * 1024**3
    software_metrics = SOFTWARE_EVENTS.issubset(supported_events)
    dtlb = "dTLB-load-misses" in supported_events
    matmul_status = "READY" if basic_cpu and software_metrics and numpy_available else "PARTIALLY_SUPPORTED"
    return {
        "matmul": {
            "status": matmul_status,
            "scope": "Scaled VGO reproduction; TCMalloc remains contingent on package availability.",
        },
        "7z": {
            "status": "READY" if basic_cpu and software_metrics else "PARTIALLY_SUPPORTED",
            "scope": "Single-threaded thread-pinning workflow after p7zip installation.",
        },
        "sad": {
            "status": "READY" if basic_cpu and dtlb and thp_readable and sudo_available else "PARTIALLY_SUPPORTED",
            "scope": (
                "Full dTLB/THP attribution needs dTLB perf access plus reversible THP privilege; "
                "otherwise retain raw data and label mitigation unavailable or attribution incomplete."
            ),
        },
        "lbm": {
            "status": "READY" if basic_cpu and software_metrics else "PARTIALLY_SUPPORTED",
            "scope": "Scaled Parboil CPU run with an actual visible CPU set, never paper's 0-63 hard-code.",
        },
        "xapian": {
            "status": "PARTIALLY_SUPPORTED" if basic_cpu and software_metrics else "UNSUPPORTED_BY_ENVIRONMENT",
            "scope": (
                "VGO methodology adaptation only; NUMA-balancing mitigation is UNSUPPORTED_BY_ENVIRONMENT "
                "on a single-node VM."
                if numa_nodes <= 1
                else "Tail-latency VGO adaptation; exact paper topology is still not reproduced."
            ),
        },
        "gpu_cases": {
            "status": "UNSUPPORTED_BY_ENVIRONMENT",
            "scope": "No NVIDIA GPU is assumed or simulated for srad GPU, RetinaNet, Stable Diffusion, LLM, or SAM2 cases.",
        },
    }


def markdown_report(payload: dict[str, Any]) -> str:
    host = payload["host"]
    perf = payload["perf"]
    permissions = payload["permissions"]
    lines = [
        "# Phase 0 - 环境可行性检查",
        "",
        "> 本文件由 `scripts/check_environment.sh` 在目标 Linux 服务器生成。它是只读检查，未安装软件、未更改 THP/sysctl/governor。",
        "",
        "## 机器快照",
        "",
        f"- 采集时间（UTC）：`{payload['captured_at']}`",
        f"- CPU：`{host['cpu_model']}`；可见 vCPU：`{host['cpu_count']}`；SMT：`{host['smt']}`",
        f"- 内存：`{host['memory_gb']:.2f} GiB`；可用内存：`{host['memory_available_gb']:.2f} GiB`；Swap：`{host['swap_total_gb']:.2f} GiB`",
        f"- NUMA node：`{host['numa_nodes']}`；虚拟化：`{host['virtualized']}`（`{host['hypervisor']}`）",
        f"- 内核：`{host['kernel']}`；CPU governor：`{', '.join(host['cpu_governors']) or 'unavailable'}`",
        f"- THP：`{payload['thp']['active_mode']}`；THP 文件可读：`{payload['thp']['readable']}`；当前用户可写：`{payload['thp']['writable_by_current_user']}`",
        f"- sudo/root：root=`{permissions['is_root']}`，non-interactive sudo=`{permissions['sudo_noninteractive']}`",
        f"- 工作目录可用磁盘：`{payload['disk']['free_gb']:.2f} GiB`",
        "",
        "## perf 逐事件能力",
        "",
        f"- perf：`{perf['version']}`；可用事件：`{', '.join(perf['supported_events']) or '无'}`",
        f"- 不可用事件：`{', '.join(item['event'] + ' (' + item['reason'] + ')' for item in perf['unsupported_events']) or '无'}`",
        "",
        "| Event | Status | Collector | Reason |",
        "|---|---|---|---|",
    ]
    for item in perf["event_results"]:
        lines.append(
            f"| `{item['event']}` | {'supported' if item['supported'] else 'unavailable'} | "
            f"`{item['collector']}` | `{item['reason'] or '-'}` |"
        )
    lines.extend(["", "## 五个 CPU 实验的环境判定", "", "| Experiment | Status | Boundary |", "|---|---|---|"])
    for name, item in payload["experiment_readiness"].items():
        lines.append(f"| {name} | **{item['status']}** | {item['scope']} |")
    lines.extend(
        [
            "",
            "## 下一步",
            "",
            "1. 若 Matmul、7z、LBM 的软件事件可用，先仅安装分析依赖并完成 Matmul calibration；不要跳到单次运行。",
            "2. 只有 `dTLB-load-misses`、THP 读取/可逆写入都确认后，才把 SAD 记为可做完整因素归因；否则保留为受限实验。",
            "3. Xapian 在单 NUMA VM 仅做 VGO 方法适配，不关闭没有实验意义的 NUMA balancing。",
            "4. 原始详情见 `results/environment/perf_capabilities.json` 和 `results/environment/environment_snapshot.json`。",
            "",
        ]
    )
    return "\n".join(lines)


def update_status(root: Path, captured_at: str) -> None:
    status = root / "STATUS.md"
    if not status.is_file():
        return
    content = status.read_text(encoding="utf-8")
    replacement = (
        f"- [x] Target Linux 8C16G environment checked (`{captured_at}`; "
        "see `docs/environment.md`)"
    )
    content = re.sub(
        r"- \[[ x]\] Target Linux 8C16G environment checked.*",
        replacement,
        content,
        count=1,
    )
    status.write_text(content, encoding="utf-8")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, help="Project root; defaults to the parent of scripts/.")
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    root = (args.root or Path(__file__).resolve().parent.parent).resolve()
    results_dir = root / "results" / "environment"
    metadata_dir = root / "data" / "metadata"
    docs_dir = root / "docs"
    results_dir.mkdir(parents=True, exist_ok=True)
    metadata_dir.mkdir(parents=True, exist_ok=True)
    docs_dir.mkdir(parents=True, exist_ok=True)

    lscpu_code, lscpu_output = run_text(["lscpu"])
    lscpu_data = parse_key_value_lines(lscpu_output) if lscpu_code == 0 else {}
    memory = meminfo()
    mem_total = memory.get("MemTotal", 0)
    mem_available = memory.get("MemAvailable", memory.get("MemFree", 0))
    swap_total = memory.get("SwapTotal", 0)
    cpu_count = os.cpu_count() or 0
    numa_nodes = visible_numa_nodes()
    virtualized, hypervisor = virtualization(lscpu_data)
    sudo_code, _ = run_text(["sudo", "-n", "true"])
    sudo_available = sudo_code == 0
    perf_version_code, perf_version_output = run_text(["perf", "--version"])
    event_results = [perf_event_result(event, sudo_available) for event in PERF_EVENTS]
    supported_events = [item["event"] for item in event_results if item["supported"]]
    unsupported_events = [
        {"event": item["event"], "reason": item["reason"], "collector": item["collector"]}
        for item in event_results
        if not item["supported"]
    ]
    disk_code, disk_output = run_text(["df", "-Pk", str(root)])
    disk_free_bytes = 0
    if disk_code == 0:
        rows = [line.split() for line in disk_output.splitlines()[1:] if line.strip()]
        if rows and len(rows[-1]) >= 4:
            disk_free_bytes = int(rows[-1][3]) * 1024
    swap_code, swap_output = run_text(["swapon", "--show", "--noheadings"])
    python_code, python_output = run_text(["python3", "--version"])
    gcc_code, gcc_output = run_text(["gcc", "--version"])
    smt_file = Path("/sys/devices/system/cpu/smt/active")
    smt = read_text(smt_file) or lscpu_data.get("Thread(s) per core", "unavailable")
    thp_readable = THP_FILE.is_file() and os.access(THP_FILE, os.R_OK)
    thp_writable = THP_FILE.is_file() and os.access(THP_FILE, os.W_OK)
    numpy_available = has_numpy() if python_code == 0 else False
    kernel_code, kernel_output = run_text(["uname", "-a"])
    os_release = read_text(Path("/etc/os-release"))

    payload: dict[str, Any] = {
        "captured_at": utc_now(),
        "schema_version": 1,
        "supported_events": supported_events,
        "unsupported_events": unsupported_events,
        "numa_nodes": numa_nodes,
        "cpu_count": cpu_count,
        "memory_gb": round(mem_total / 1024**3, 3),
        "virtualized": virtualized,
        "host": {
            "kernel": first_line(kernel_output) if kernel_code == 0 else "unavailable",
            "os_release": os_release,
            "cpu_model": lscpu_data.get("Model name", "unavailable"),
            "cpu_count": cpu_count,
            "memory_gb": round(mem_total / 1024**3, 3),
            "memory_available_gb": round(mem_available / 1024**3, 3),
            "swap_total_gb": round(swap_total / 1024**3, 3),
            "swap_active": bool(swap_output.strip()) if swap_code == 0 else False,
            "numa_nodes": numa_nodes,
            "virtualized": virtualized,
            "hypervisor": hypervisor,
            "smt": smt,
            "cpu_governors": cpu_governors(),
            "lscpu": lscpu_output,
            "cpuinfo_excerpt": "\n".join(read_text(Path("/proc/cpuinfo")).splitlines()[:40]),
        },
        "software": {
            "python3": first_line(python_output) if python_code == 0 else "unavailable",
            "numpy_available": numpy_available,
            "gcc": first_line(gcc_output) if gcc_code == 0 else "unavailable",
            "perf": first_line(perf_version_output) if perf_version_code == 0 else "unavailable",
        },
        "permissions": {
            "is_root": os.geteuid() == 0 if hasattr(os, "geteuid") else False,
            "sudo_noninteractive": sudo_available,
        },
        "thp": {
            "path": str(THP_FILE),
            "enabled_raw": read_text(THP_FILE),
            "active_mode": current_thp_mode(THP_FILE),
            "defrag_raw": read_text(THP_DEFRAG_FILE),
            "readable": thp_readable,
            "writable_by_current_user": thp_writable,
            "write_test": "not attempted during read-only Phase 0",
        },
        "disk": {"free_gb": round(disk_free_bytes / 1024**3, 3), "path": str(root)},
        "perf": {
            "version": first_line(perf_version_output) if perf_version_code == 0 else "unavailable",
            "supported_events": supported_events,
            "unsupported_events": unsupported_events,
            "event_results": event_results,
            "hardware_pmu_event_available": bool(set(supported_events) & HARDWARE_EVENTS),
            "software_event_set_available": SOFTWARE_EVENTS.issubset(set(supported_events)),
        },
        "raw_commands": {
            "numactl_hardware": run_text(["numactl", "--hardware"])[1],
            "free_h": run_text(["free", "-h"])[1],
            "lscpu_numa": "\n".join(
                line for line in lscpu_output.splitlines() if "numa" in line.lower()
            ),
        },
    }
    payload["experiment_readiness"] = readiness(
        cpu_count,
        mem_total,
        numa_nodes,
        set(supported_events),
        thp_readable,
        sudo_available,
        numpy_available,
    )

    encoded = json.dumps(payload, ensure_ascii=False, indent=2) + "\n"
    for path in (results_dir / "perf_capabilities.json", metadata_dir / "perf_capabilities.json"):
        path.write_text(encoded, encoding="utf-8")
    (results_dir / "environment_snapshot.json").write_text(encoded, encoding="utf-8")
    (docs_dir / "environment.md").write_text(markdown_report(payload), encoding="utf-8")
    update_status(root, payload["captured_at"])

    print(f"environment_report={docs_dir / 'environment.md'}")
    print(f"perf_capabilities={results_dir / 'perf_capabilities.json'}")
    print(f"supported_events={','.join(supported_events) or 'none'}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
