#!/usr/bin/env bash
set -Eeuo pipefail

SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd -P)"
ROOT_DIR="$(cd -- "$SCRIPT_DIR/.." && pwd -P)"
CONFIG_FILE="$ROOT_DIR/config/experiment.env"
PHASE0_REPORT="$ROOT_DIR/results/environment/perf_capabilities.json"
SHARP_COMMIT="d22926f541f1f3cfbd2e9d805fd087b4607e6712"

log() { printf '[setup] %s\n' "$*"; }
die() { printf '[setup] ERROR: %s\n' "$*" >&2; exit 1; }

[[ -f "$CONFIG_FILE" ]] || die "Missing config: $CONFIG_FILE"
[[ -f "$PHASE0_REPORT" ]] || die "Phase 0 is mandatory before installation. Run: bash scripts/check_environment.sh"
# shellcheck disable=SC1090
set -a
source "$CONFIG_FILE"
set +a

resolve_path() {
  case "$1" in
    /*) printf '%s\n' "$1" ;;
    *) printf '%s/%s\n' "$ROOT_DIR" "$1" ;;
  esac
}

PARBOIL_ROOT="$(resolve_path "$VGO_PARBOIL_ROOT")"
SHARP_ROOT="$(resolve_path "$VGO_SHARP_ROOT")"
VENDOR_DIR="$ROOT_DIR/vendor"
DOWNLOAD_DIR="$VENDOR_DIR/downloads"
ANALYSIS_VENV="$ROOT_DIR/.venv"
SHARP_VENV="$ROOT_DIR/.venv-sharp"

if [[ ! -r /etc/os-release ]]; then
  die "This installer must run on Ubuntu Linux."
fi
# shellcheck disable=SC1091
source /etc/os-release
if [[ "${ID:-}" != "ubuntu" ]]; then
  die "Expected Ubuntu 22.04; detected ${PRETTY_NAME:-unknown}."
fi
if [[ "${VERSION_ID:-}" != "22.04" ]]; then
  log "WARNING: tested on Ubuntu 22.04; detected ${PRETTY_NAME:-unknown}."
fi

log "Installing system packages"
sudo apt-get update
sudo DEBIAN_FRONTEND=noninteractive apt-get install -y \
  build-essential ca-certificates curl git jq numactl p7zip-full \
  libev-dev libopenmpi-dev openmpi-bin patch pkg-config libtcmalloc-minimal4 \
  python3 python3-dev python3-lib2to3 python3-pip python3-venv python-is-python3 \
  sysstat time tmux util-linux linux-tools-common

if ! perf --version >/dev/null 2>&1; then
  log "Trying kernel-specific perf package"
  sudo DEBIAN_FRONTEND=noninteractive apt-get install -y "linux-tools-$(uname -r)" || true
fi
perf --version >/dev/null 2>&1 || die "perf is still unavailable after package installation."
sevenzip_banner="$(7z | sed -n '2p')"
[[ "$sevenzip_banner" == *"16.02"* ]] || \
  die "Expected Ubuntu 22.04 p7zip 16.02; detected: $sevenzip_banner"

log "Creating pinned analysis environment"
python3 -m venv "$ANALYSIS_VENV"
"$ANALYSIS_VENV/bin/python" -m pip install --upgrade pip wheel
"$ANALYSIS_VENV/bin/python" -m pip install -r "$ROOT_DIR/requirements-analysis.txt"

log "Installing SHARP v3.0.0"
if [[ -e "$SHARP_ROOT" && ! -d "$SHARP_ROOT/.git" ]]; then
  die "$SHARP_ROOT exists but is not a SHARP Git checkout; move it aside first."
fi
if [[ ! -d "$SHARP_ROOT/.git" ]]; then
  git clone --branch v3.0.0 --depth 1 https://github.com/HewlettPackard/SHARP.git "$SHARP_ROOT"
fi
actual_sharp_commit="$(git -C "$SHARP_ROOT" rev-parse HEAD)"
[[ "$actual_sharp_commit" == "$SHARP_COMMIT" ]] || \
  die "Unexpected SHARP commit: $actual_sharp_commit"

python3 -m venv "$SHARP_VENV"
"$SHARP_VENV/bin/python" -m pip install --upgrade pip wheel
"$SHARP_VENV/bin/python" -m pip install -r "$SHARP_ROOT/requirements.txt"

mkdir -p "$DOWNLOAD_DIR"

download_and_verify() {
  local filename="$1"
  local sha256="$2"
  local url="https://www.phoronix-test-suite.com/benchmark-files/$filename"
  local target="$DOWNLOAD_DIR/$filename"

  if [[ ! -f "$target" ]]; then
    log "Downloading $filename"
    curl --fail --location --retry 3 --retry-delay 3 "$url" --output "$target"
  fi
  printf '%s  %s\n' "$sha256" "$target" | sha256sum --check --status || \
    die "SHA-256 mismatch for $target"
}

download_and_verify \
  pb2.5driver.tgz \
  32f6eedc30faa0e724af4546060dc1f291e36f224530836961510028f1555bde
download_and_verify \
  pb2.5benchmarks.tgz \
  1b862fd8cc9a1e291dab3491ba84e4e8dd34f6b59d2913a633a0bb15ff5634cc
download_and_verify \
  pb2.5datasets_standard.tgz \
  449916452aa75e440d1a4b2b8aa42f6d9e5d70591f2890544f6f0a830e81bea0

if [[ ! -f "$PARBOIL_ROOT/.vgo-ready" ]]; then
  [[ ! -e "$PARBOIL_ROOT" ]] || \
    die "$PARBOIL_ROOT already exists without .vgo-ready; move it aside and rerun."

  stage_dir="$(mktemp -d "$VENDOR_DIR/.parboil-stage.XXXXXX")"
  cleanup_stage() {
    if [[ -n "${stage_dir:-}" && "$stage_dir" == "$VENDOR_DIR"/.parboil-stage.* ]]; then
      rm -rf -- "$stage_dir"
    fi
  }
  trap cleanup_stage EXIT

  tar -xzf "$DOWNLOAD_DIR/pb2.5driver.tgz" -C "$stage_dir"
  tar -xzf "$DOWNLOAD_DIR/pb2.5benchmarks.tgz" -C "$stage_dir"
  tar -xzf "$DOWNLOAD_DIR/pb2.5datasets_standard.tgz" -C "$stage_dir"
  mv -- "$stage_dir/benchmarks" "$stage_dir/parboil/benchmarks"
  mv -- "$stage_dir/datasets" "$stage_dir/parboil/datasets"
  chmod u+x "$stage_dir/parboil/parboil" "$stage_dir/parboil"/benchmarks/*/tools/compare-output

  log "Porting the legacy Parboil driver from Python 2 syntax to Python 3"
  mapfile -d '' parboil_py_files < <(
    find "$stage_dir/parboil/driver" "$stage_dir/parboil/common/python" \
      -type f -name '*.py' -print0
  )
  parboil_port_files=(
    "$stage_dir/parboil/parboil"
    "${parboil_py_files[@]}"
    "$stage_dir/parboil/benchmarks/lbm/tools/compare-output"
    "$stage_dir/parboil/benchmarks/sad/tools/compare-output"
  )
  python3 -m lib2to3 -w -n "${parboil_port_files[@]}"
  find "$stage_dir/parboil" -type f -name '*.pyc' -delete
  # The legacy Parboil tarball contains mixed CRLF/LF files.  lib2to3 can
  # preserve those endings, while our compatibility patch is LF-based;
  # normalize the converted text files before applying the patch.
  find "$stage_dir/parboil" -type f \( -name '*.py' -o -name 'parboil' -o -name 'compare-output' \) \
    -exec sed -i 's/\r$//' {} +
  patch --directory="$stage_dir/parboil" --strip=1 --forward \
    < "$ROOT_DIR/vendor/parboil-python3-compat.patch"
  for python_file in "${parboil_port_files[@]}"; do
    expand --tabs=8 "$python_file" > "${python_file}.expanded"
    mv -- "${python_file}.expanded" "$python_file"
  done
  chmod u+x "$stage_dir/parboil/parboil" \
    "$stage_dir/parboil/benchmarks/lbm/tools/compare-output" \
    "$stage_dir/parboil/benchmarks/sad/tools/compare-output"
  python3 -m compileall -q "$stage_dir/parboil/driver" "$stage_dir/parboil/common/python"
  python3 -m py_compile \
    "$stage_dir/parboil/parboil" \
    "$stage_dir/parboil/benchmarks/lbm/tools/compare-output" \
    "$stage_dir/parboil/benchmarks/sad/tools/compare-output"
  (
    cd "$stage_dir/parboil"
    python3 ./parboil list >/dev/null
  )

  : > "$stage_dir/parboil/common/Makefile.conf"
  cat > "$stage_dir/parboil/common/platform/c.default.mk" <<'EOF'
CC = gcc
PLATFORM_CFLAGS = -O3 -ffast-math
CXX = g++
PLATFORM_CXXFLAGS = -O3 -ffast-math
LINKER = g++
PLATFORM_LDFLAGS = -lm -lpthread
EOF

  log "Compiling Parboil LBM omp_cpu and SAD cpu"
  (
    cd "$stage_dir/parboil"
    python3 ./parboil compile lbm omp_cpu
    python3 ./parboil compile sad cpu
  )
  printf 'Parboil 2.5 prepared for VGO on %s\n' "$(date --iso-8601=seconds)" > \
    "$stage_dir/parboil/.vgo-ready"

  mv -- "$stage_dir/parboil" "$PARBOIL_ROOT"
  stage_dir=""
  trap - EXIT
else
  log "Parboil is already prepared; keeping the existing verified tree"
fi

mkdir -p "$ROOT_DIR/data/metadata" "$ROOT_DIR/data/raw" "$ROOT_DIR/data/analysis" \
  "$ROOT_DIR/results/environment" "$ROOT_DIR/logs"
chmod u+x "$ROOT_DIR/scripts"/*.sh
chmod u+x "$ROOT_DIR/benchmarks/matmul"/*.py

versions_file="$ROOT_DIR/data/metadata/software_versions.lock.md"
cat > "$versions_file" <<EOF
# VGO software version lock

- Generated: $(date --iso-8601=seconds)
- OS: ${PRETTY_NAME}
- Kernel: $(uname -r)
- Python: $(python3 --version 2>&1)
- GCC: $(gcc --version | head -n 1)
- perf: $(perf --version 2>&1 | head -n 1)
- 7-Zip: $sevenzip_banner
- TCMalloc: $(ldconfig -p 2>/dev/null | grep -m1 'libtcmalloc' || true)
- SHARP tag: v3.0.0
- SHARP commit: $actual_sharp_commit
- SHARP requirements SHA-256: $(sha256sum "$SHARP_ROOT/requirements.txt" | awk '{print $1}')
- Parboil: 2.5, Python-3 port via lib2to3 plus compatibility patch
- Parboil C/C++ optimization flags: -O3 -ffast-math
- Parboil compatibility patch SHA-256: $(sha256sum "$ROOT_DIR/vendor/parboil-python3-compat.patch" | awk '{print $1}')
- Analysis requirements SHA-256: $(sha256sum "$ROOT_DIR/requirements-analysis.txt" | awk '{print $1}')
- pb2.5driver.tgz SHA-256: 32f6eedc30faa0e724af4546060dc1f291e36f224530836961510028f1555bde
- pb2.5benchmarks.tgz SHA-256: 1b862fd8cc9a1e291dab3491ba84e4e8dd34f6b59d2913a633a0bb15ff5634cc
- pb2.5datasets_standard.tgz SHA-256: 449916452aa75e440d1a4b2b8aa42f6d9e5d70591f2890544f6f0a830e81bea0

## Analysis Python environment

~~~text
$("$ANALYSIS_VENV/bin/python" -m pip freeze)
~~~

## SHARP Python environment

~~~text
$("$SHARP_VENV/bin/python" -m pip freeze)
~~~
EOF

log "Running a SHARP launcher smoke test"
(
  cd "$SHARP_ROOT"
  "$SHARP_VENV/bin/python" launcher/launch.py \
    --skip-sys-specs -b local -r 1 -e vgo-setup-smoke -t sleep-smoke sleep 0.01
)

log "Setup complete"
log "Next: $ROOT_DIR/scripts/validate_machine.sh"
