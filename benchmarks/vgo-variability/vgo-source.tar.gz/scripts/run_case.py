#!/usr/bin/env python3
"""Run one VGO benchmark phase and append one immutable CSV row per execution."""

from __future__ import annotations

import argparse
import csv
import json
import math
import os
from pathlib import Path
import platform
import re
import shlex
import shutil
import signal
import statistics
import subprocess
import sys
import tempfile
import time
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any, Iterable


CSV_FIELDS = [
    "run_id",
    "benchmark",
    "phase",
    "condition",
    "repetition",
    "timestamp",
    "wall_time_s",
    "app_metric",
    "app_metric_name",
    "exit_code",
    "correctness",
    "context_switches",
    "cpu_migrations",
    "page_faults",
    "cache_references",
    "dTLB_load_misses",
    "dTLB_loads",
    "cache_misses",
    "branch_misses",
    "iTLB_load_misses",
    "emulation_faults",
    "L1_icache_load_misses",
    "L1_dcache_load_misses",
    "LLC_load_misses",
    "node_load_misses",
    "cpu_clock",
    "cycles",
    "instructions",
    "perf_running_pct",
    "sys_time_s",
    "major_page_faults",
    "minor_page_faults",
    "max_rss_kib",
    "percent_cpu",
    "involuntary_context_switches",
    "voluntary_context_switches",
    "cpu_steal",
    "thp_state",
    "timeout",
    "log_file",
]

PERF_EVENT_COLUMNS = {
    "cache-references": "cache_references",
    "cache-misses": "cache_misses",
    "context-switches": "context_switches",
    "branch-misses": "branch_misses",
    "cpu-migrations": "cpu_migrations",
    "page-faults": "page_faults",
    "dTLB-load-misses": "dTLB_load_misses",
    "dTLB-loads": "dTLB_loads",
    "iTLB-load-misses": "iTLB_load_misses",
    "emulation-faults": "emulation_faults",
    "L1-icache-load-misses": "L1_icache_load_misses",
    "L1-dcache-load-misses": "L1_dcache_load_misses",
    "LLC-load-misses": "LLC_load_misses",
    "node-load-misses": "node_load_misses",
    "cpu-clock": "cpu_clock",
    "cycles": "cycles",
    "instructions": "instructions",
}

VALID_EXPERIMENT_ID = re.compile(r"^[A-Za-z0-9._-]+$")
THP_FILE = Path("/sys/kernel/mm/transparent_hugepage/enabled")
PROFILE_PHASES = {"profile", "profile_probe"}


@dataclass
class BenchmarkSpec:
    command: list[str]
    cwd: Path
    env: dict[str, str]
    app_metric_name: str


@dataclass
class CommandResult:
    exit_code: int
    timed_out: bool
    stdout: str
    stderr: str
    wall_time_s: float
    perf: dict[str, float | None]
    bintime: dict[str, float | None]
    cpu_steal_pct: float


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="milliseconds")


def load_env_file(path: Path) -> dict[str, str]:
    values: dict[str, str] = {}
    for raw_line in path.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        key = key.strip()
        value = value.strip()
        if len(value) >= 2 and value[0] == value[-1] and value[0] in {'"', "'"}:
            value = value[1:-1]
        values[key] = value
    for key, value in os.environ.items():
        if key.startswith("VGO_"):
            values[key] = value
    return values


def resolve_config_path(root: Path, raw: str) -> Path:
    path = Path(raw).expanduser()
    return path if path.is_absolute() else root / path


def online_cpu_ids() -> list[int]:
    if hasattr(os, "sched_getaffinity"):
        available = sorted(os.sched_getaffinity(0))
        if available:
            return available
    online_file = Path("/sys/devices/system/cpu/online")
    text = online_file.read_text(encoding="ascii").strip() if online_file.exists() else ""
    cpus: list[int] = []
    for part in text.split(",") if text else []:
        if "-" in part:
            start, end = (int(value) for value in part.split("-", 1))
            cpus.extend(range(start, end + 1))
        elif part:
            cpus.append(int(part))
    if not cpus:
        cpus = list(range(os.cpu_count() or 1))
    return cpus


def normalize_cpuset(raw: str, threads: int) -> str:
    cpus = online_cpu_ids()
    if raw.lower() == "auto":
        if len(cpus) < threads:
            raise RuntimeError(f"Need {threads} online CPUs, found {len(cpus)}")
        return ",".join(str(cpu) for cpu in cpus[:threads])

    requested: list[int] = []
    for part in raw.split(","):
        part = part.strip()
        if not part:
            continue
        if "-" in part:
            start, end = (int(value) for value in part.split("-", 1))
            requested.extend(range(start, end + 1))
        else:
            requested.append(int(part))
    if len(set(requested)) < threads:
        raise RuntimeError(f"CPU set {raw!r} contains fewer than {threads} distinct CPUs")
    missing = sorted(set(requested) - set(cpus))
    if missing:
        raise RuntimeError(f"CPU set includes offline or invisible CPUs: {missing}")
    return raw


def condition_for_phase(phase: str, requested: str | None) -> str:
    if phase in {"pilot", "blocked"}:
        if phase == "blocked" and requested is None:
            raise ValueError("Phase blocked requires --condition baseline|mitigated")
        return requested or "baseline"
    expected = {
        "correctness": "baseline",
        "baseline": "baseline",
        "profile": "baseline",
        "profile_probe": "baseline",
        "mitigated": "mitigated",
        "rollback": "baseline",
    }[phase]
    if requested is not None and requested != expected:
        raise ValueError(f"Phase {phase} requires condition={expected}")
    return expected


def matmul_dimension(root: Path, config: dict[str, str]) -> int:
    configured = config.get("VGO_MATMUL_DIM", "auto").strip().lower()
    if configured != "auto":
        dimension = int(configured)
        if dimension < 16:
            raise RuntimeError("VGO_MATMUL_DIM must be at least 16")
        return dimension
    calibration_path = root / "config" / "matmul_calibration.json"
    if not calibration_path.is_file():
        raise RuntimeError(
            "Matmul has not been calibrated. Run benchmarks/matmul/calibrate.py on this host "
            "before collecting baseline data."
        )
    try:
        calibration = json.loads(calibration_path.read_text(encoding="utf-8"))
        dimension = int(calibration["dimension"])
    except (OSError, ValueError, KeyError, json.JSONDecodeError) as error:
        raise RuntimeError(f"Invalid Matmul calibration file: {calibration_path}: {error}") from error
    if calibration.get("host") and calibration["host"] != platform.node():
        raise RuntimeError(
            "Matmul calibration belongs to a different host; preserve it as evidence and recalibrate "
            f"on {platform.node()!r}."
        )
    if dimension < 16:
        raise RuntimeError(f"Invalid Matmul calibration dimension: {dimension}")
    return dimension


def find_tcmalloc_library(config: dict[str, str]) -> Path | None:
    configured = config.get("VGO_TCMALLOC_LIBRARY", "auto").strip()
    if configured and configured.lower() != "auto":
        path = Path(configured).expanduser()
        return path if path.is_file() else None
    candidates = [
        Path("/usr/lib/x86_64-linux-gnu/libtcmalloc.so.4"),
        Path("/usr/lib/x86_64-linux-gnu/libtcmalloc_minimal.so.4"),
        Path("/usr/lib64/libtcmalloc.so.4"),
        Path("/usr/lib64/libtcmalloc_minimal.so.4"),
    ]
    for directory in (Path("/usr/lib"), Path("/usr/local/lib")):
        if directory.is_dir():
            candidates.extend(sorted(directory.glob("**/libtcmalloc*.so*")))
    for candidate in candidates:
        if candidate.is_file():
            return candidate
    return None


def build_benchmark_spec(
    benchmark: str,
    condition: str,
    root: Path,
    config: dict[str, str],
) -> BenchmarkSpec:
    env = dict(os.environ)
    env.update({"LC_ALL": "C", "LANG": "C", "PYTHONHASHSEED": "0"})

    if benchmark == "matmul":
        dimension = matmul_dimension(root, config)
        dtype = config.get("VGO_MATMUL_DTYPE", "float32")
        threads = int(config.get("VGO_MATMUL_THREADS", "1"))
        if dtype not in {"float32", "float64"}:
            raise RuntimeError(f"Unsupported VGO_MATMUL_DTYPE: {dtype}")
        if threads <= 0:
            raise RuntimeError("VGO_MATMUL_THREADS must be positive")
        for variable in (
            "OPENBLAS_NUM_THREADS",
            "OMP_NUM_THREADS",
            "MKL_NUM_THREADS",
            "BLIS_NUM_THREADS",
            "NUMEXPR_NUM_THREADS",
        ):
            env[variable] = str(threads)
        command = [
            sys.executable,
            str(root / "benchmarks" / "matmul" / "benchmark.py"),
            "--dimension",
            str(dimension),
            "--dtype",
            dtype,
            "--seed",
            config.get("VGO_MATMUL_SEED", "2026"),
        ]
        if condition == "mitigated":
            library = find_tcmalloc_library(config)
            if library is None:
                raise RuntimeError(
                    "MITIGATION_UNAVAILABLE: TCMalloc library was not found. Install libtcmalloc-minimal4 "
                    "after Phase 0 or set VGO_TCMALLOC_LIBRARY to a verified absolute path."
                )
            existing_preload = env.get("LD_PRELOAD", "")
            env["LD_PRELOAD"] = str(library) + (f":{existing_preload}" if existing_preload else "")
        return BenchmarkSpec(command, root, env, "compute_time_s")

    if benchmark == "7z":
        program = config.get("VGO_7Z_COMMAND", "7z")
        resolved_program = shutil.which(program)
        if resolved_program is None:
            raise RuntimeError(f"Cannot find 7-Zip executable: {program}")
        command = [resolved_program, *shlex.split(config.get("VGO_7Z_ARGS", "b -mmt1"))]
        if condition == "mitigated":
            core = int(config.get("VGO_7Z_PIN_CORE", "2"))
            if core not in online_cpu_ids():
                raise RuntimeError(f"Configured 7-Zip core {core} is not online")
            command = ["taskset", "-c", str(core), *command]
        return BenchmarkSpec(command, root, env, "wall_time_s")

    parboil_root = resolve_config_path(root, config.get("VGO_PARBOIL_ROOT", "vendor/parboil-2.5"))
    if not (parboil_root / ".vgo-ready").is_file():
        raise RuntimeError(f"Parboil is not prepared: {parboil_root}; run setup_ubuntu.sh")

    if benchmark == "lbm":
        threads = int(config.get("VGO_LBM_THREADS", "8"))
        cpuset = normalize_cpuset(config.get("VGO_LBM_CPUSET", "auto"), threads)
        for affinity_variable in (
            "OMP_PROC_BIND",
            "OMP_PLACES",
            "GOMP_CPU_AFFINITY",
            "KMP_AFFINITY",
        ):
            env.pop(affinity_variable, None)
        env.update({"OMP_NUM_THREADS": str(threads), "OMP_DYNAMIC": "FALSE"})
        command = ["python3", "./parboil", "run", "lbm", "omp_cpu", "long"]
        if condition == "mitigated":
            env.update({"OMP_PROC_BIND": "TRUE", "OMP_PLACES": "threads"})
            command = ["taskset", "-c", cpuset, *command]
        return BenchmarkSpec(command, parboil_root, env, "compute_time_s")

    if benchmark == "sad":
        command = ["python3", "./parboil", "run", "sad", "cpu", "large"]
        return BenchmarkSpec(command, parboil_root, env, "compute_time_s")

    raise ValueError(f"Unsupported benchmark: {benchmark}")


def perf_events_for_phase(
    benchmark: str,
    phase: str,
    config: dict[str, str],
) -> str | None:
    if phase not in PROFILE_PHASES:
        return None
    explicit_override = config.get("VGO_PERF_EVENTS")
    if phase == "profile_probe":
        events = config.get(
            "VGO_PERF_EVENTS_PROBE_OVERRIDE",
            config.get("VGO_PERF_EVENTS_PROBE", ""),
        )
    elif explicit_override:
        events = explicit_override
    else:
        events = config.get(f"VGO_PERF_EVENTS_{benchmark.upper()}", "")
    event_names = [event.strip() for event in events.split(",") if event.strip()]
    if not event_names:
        raise RuntimeError(f"No perf events configured for {benchmark}/{phase}")
    unknown_events = [
        event
        for event in event_names
        if event.split(":", 1)[0] not in PERF_EVENT_COLUMNS
    ]
    if unknown_events:
        raise RuntimeError(f"Unsupported perf event names in VGO config: {unknown_events}")
    if phase == "profile" and len(event_names) > 4:
        raise RuntimeError(
            "Formal profile event groups must contain at most four events; "
            "use VGO_PERF_EVENTS_<BENCHMARK> or an explicit <=4-event override"
        )
    return ",".join(event_names)


def missing_requested_perf_events(
    row: dict[str, Any], perf_events: str | None
) -> list[str]:
    if not perf_events:
        return []
    missing: list[str] = []
    for event in perf_events.split(","):
        event = event.strip()
        canonical = event.split(":", 1)[0]
        column = PERF_EVENT_COLUMNS.get(canonical)
        if column is None or parse_number(str(row.get(column, ""))) is None:
            missing.append(event)
    return missing


def read_thp_mode() -> str:
    if not THP_FILE.is_file():
        return "unavailable"
    text = THP_FILE.read_text(encoding="ascii", errors="replace")
    match = re.search(r"\[([^]]+)\]", text)
    return match.group(1) if match else "unknown"


def target_thp_mode(benchmark: str, condition: str) -> str | None:
    if benchmark != "sad":
        return None
    return "always" if condition == "mitigated" else "madvise"


def set_thp_mode(mode: str) -> None:
    if mode not in {"always", "madvise", "never"}:
        raise ValueError(f"Invalid THP mode: {mode}")
    result = subprocess.run(
        ["sudo", "-n", "tee", str(THP_FILE)],
        input=f"{mode}\n",
        text=True,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.PIPE,
        check=False,
    )
    if result.returncode != 0:
        raise RuntimeError(f"Unable to set THP={mode}: {result.stderr.strip()}")
    actual = read_thp_mode()
    if actual != mode:
        raise RuntimeError(f"Requested THP={mode}, active mode is {actual}")


def read_cpu_totals() -> tuple[int, int]:
    fields = Path("/proc/stat").read_text(encoding="ascii").splitlines()[0].split()
    values = [int(value) for value in fields[1:9]]
    while len(values) < 8:
        values.append(0)
    return sum(values), values[7]


def cpu_steal_pct(before: tuple[int, int], after: tuple[int, int]) -> float:
    total_delta = after[0] - before[0]
    steal_delta = after[1] - before[1]
    if total_delta <= 0:
        return 0.0
    return max(0.0, 100.0 * steal_delta / total_delta)


def parse_number(raw: str) -> float | None:
    value = raw.strip().replace(" ", "")
    if not value or value.startswith("<") or value.upper() in {"NA", "N/A"}:
        return None
    value = value.replace(",", "")
    try:
        return float(value.rstrip("%"))
    except ValueError:
        return None


def parse_perf_file(path: Path) -> dict[str, float | None]:
    values: dict[str, float | None] = {column: None for column in PERF_EVENT_COLUMNS.values()}
    running_percentages: list[float] = []
    counted_events = 0
    if not path.is_file():
        values["perf_running_pct"] = None
        return values

    with path.open("r", encoding="utf-8", errors="replace", newline="") as handle:
        for row in csv.reader(handle):
            if len(row) < 3:
                continue
            event = row[2].strip().split(":", 1)[0]
            column = PERF_EVENT_COLUMNS.get(event)
            if column:
                values[column] = parse_number(row[0])
                if values[column] is not None:
                    counted_events += 1
            for field in row[3:6]:
                if "%" in field:
                    parsed = parse_number(field)
                    if parsed is not None:
                        running_percentages.append(parsed)
    values["perf_running_pct"] = (
        min(running_percentages)
        if running_percentages
        else (100.0 if counted_events else None)
    )
    return values


def parse_bintime_file(path: Path) -> dict[str, float | None]:
    keys = [
        "wall_time_s",
        "sys_time_s",
        "major_page_faults",
        "minor_page_faults",
        "max_rss_kib",
        "percent_cpu",
        "involuntary_context_switches",
        "voluntary_context_switches",
    ]
    values = {key: None for key in keys}
    if not path.is_file():
        return values
    line = path.read_text(encoding="utf-8", errors="replace").strip().splitlines()
    if not line:
        return values
    parts = line[-1].split(",")
    if parts and parts[0] == "VGO_BINTIME":
        parts = parts[1:]
    for key, raw in zip(keys, parts):
        values[key] = parse_number(raw)
    return values


def run_process(
    command: list[str],
    cwd: Path,
    env: dict[str, str],
    timeout_s: float,
) -> tuple[int, bool, str, str]:
    process = subprocess.Popen(
        command,
        cwd=cwd,
        env=env,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
        start_new_session=True,
    )
    try:
        stdout, stderr = process.communicate(timeout=timeout_s)
        return process.returncode, False, stdout, stderr
    except subprocess.TimeoutExpired:
        try:
            os.killpg(process.pid, signal.SIGTERM)
            stdout, stderr = process.communicate(timeout=5)
        except (ProcessLookupError, subprocess.TimeoutExpired):
            try:
                os.killpg(process.pid, signal.SIGKILL)
            except ProcessLookupError:
                pass
            stdout, stderr = process.communicate()
        return 124, True, stdout, stderr


def run_once(
    spec: BenchmarkSpec,
    profile: bool,
    timeout_s: float,
    config: dict[str, str],
    perf_events: str | None = None,
) -> CommandResult:
    with tempfile.TemporaryDirectory(prefix="vgo-run-") as temp_dir_name:
        temp_dir = Path(temp_dir_name)
        perf_file = temp_dir / "perf.csv"
        bintime_file = temp_dir / "bintime.csv"
        command = list(spec.command)

        if profile:
            if not perf_events:
                raise RuntimeError("Profile execution requires an explicit perf event list")
            timed_command = [
                "/usr/bin/time",
                "-f",
                "VGO_BINTIME,%e,%S,%F,%R,%M,%P,%c,%w",
                "-o",
                str(bintime_file),
                "--",
                *command,
            ]
            use_sudo = config.get("VGO_PERF_USE_SUDO", "1") == "1"
            preserve = (
                "OPENBLAS_NUM_THREADS,OMP_NUM_THREADS,OMP_DYNAMIC,OMP_PROC_BIND,OMP_PLACES,"
                "MKL_NUM_THREADS,BLIS_NUM_THREADS,NUMEXPR_NUM_THREADS,LD_PRELOAD,LC_ALL,LANG,PYTHONHASHSEED"
            )
            payload = timed_command
            if use_sudo and os.geteuid() != 0:
                payload = [
                    "setpriv",
                    f"--reuid={os.getuid()}",
                    f"--regid={os.getgid()}",
                    "--init-groups",
                    "--",
                    *timed_command,
                ]
            perf_command = [
                "perf",
                "stat",
                "-x",
                ",",
                "--no-big-num",
                "-o",
                str(perf_file),
                "-e",
                perf_events,
                "--",
                *payload,
            ]
            if use_sudo:
                command = ["sudo", "-n", f"--preserve-env={preserve}", *perf_command]
            else:
                command = perf_command

        before = read_cpu_totals()
        start = time.perf_counter()
        exit_code, timed_out, stdout, stderr = run_process(command, spec.cwd, spec.env, timeout_s)
        wall_time = time.perf_counter() - start
        after = read_cpu_totals()

        return CommandResult(
            exit_code=exit_code,
            timed_out=timed_out,
            stdout=stdout,
            stderr=stderr,
            wall_time_s=wall_time,
            perf=parse_perf_file(perf_file) if profile else {},
            bintime=parse_bintime_file(bintime_file) if profile else {},
            cpu_steal_pct=cpu_steal_pct(before, after),
        )


def benchmark_correct(benchmark: str, result: CommandResult) -> bool:
    if result.exit_code != 0 or result.timed_out:
        return False
    combined = f"{result.stdout}\n{result.stderr}"
    if benchmark == "matmul":
        return "VGO_MATMUL_OK" in combined and bool(re.search(r"(?m)^Compute:\s*[0-9]", combined))
    if benchmark == "7z":
        return bool(re.search(r"(?m)^(Avr:|Tot:)|MIPS", combined))
    return bool(re.search(r"(?m)^Pass\s*$", combined)) and "mismatch" not in combined.lower()


def app_metric(benchmark: str, result: CommandResult) -> tuple[float, str]:
    output = f"{result.stdout}\n{result.stderr}"
    if benchmark == "7z":
        matches = re.findall(r"(?im)^Avr:\s*([0-9]+(?:\.[0-9]+)?)", output)
        if matches:
            return float(matches[-1]), "avg_compression_bandwidth_kib_s"
    if benchmark in {"matmul", "lbm", "sad"}:
        matches = re.findall(r"(?im)^Compute:\s*([0-9]+(?:\.[0-9]+)?)", output)
        if matches:
            return float(matches[-1]), "compute_time_s"
    return result.wall_time_s, "wall_time_s"


def timeout_from_pilot(raw_root: Path, benchmark: str, fallback: float) -> float:
    pilot_file = raw_root / benchmark / "pilot_baseline.csv"
    if not pilot_file.is_file():
        return fallback
    values: list[float] = []
    with pilot_file.open("r", encoding="utf-8", newline="") as handle:
        for row in csv.DictReader(handle):
            try:
                if int(float(row.get("correctness", "0"))) == 1:
                    values.append(float(row["wall_time_s"]))
            except (KeyError, TypeError, ValueError):
                continue
    if not values:
        return fallback
    values.sort()
    index = min(len(values) - 1, math.ceil(0.99 * len(values)) - 1)
    return max(60.0, 3.0 * values[index])


def existing_repetitions(csv_path: Path) -> int:
    maximum = 0
    with csv_path.open("r", encoding="utf-8", newline="") as handle:
        for row in csv.DictReader(handle):
            try:
                maximum = max(maximum, int(row["repetition"]))
            except (KeyError, TypeError, ValueError):
                continue
    return maximum


def validate_existing_csv(csv_path: Path) -> None:
    with csv_path.open("r", encoding="utf-8", newline="") as handle:
        reader = csv.reader(handle)
        header = next(reader, None)
    if header != CSV_FIELDS:
        raise RuntimeError(
            f"Existing raw CSV schema does not match this runner; preserve it and use a new "
            f"experiment-id: {csv_path}"
        )


def controlled_environment(spec: BenchmarkSpec) -> dict[str, str]:
    return {
        key: spec.env[key]
        for key in [
            "OMP_NUM_THREADS",
            "OMP_DYNAMIC",
            "OMP_PROC_BIND",
            "OMP_PLACES",
            "OPENBLAS_NUM_THREADS",
            "MKL_NUM_THREADS",
            "BLIS_NUM_THREADS",
            "NUMEXPR_NUM_THREADS",
            "LD_PRELOAD",
            "LC_ALL",
        ]
        if key in spec.env
    }


def resume_signature(
    args: argparse.Namespace,
    spec: BenchmarkSpec,
    condition: str,
    timeout_s: float,
    profile_events: str | None,
) -> dict[str, Any]:
    return {
        "experiment_id": args.experiment_id,
        "benchmark": args.benchmark,
        "phase": args.phase,
        "condition": condition,
        "timeout_s": timeout_s,
        "command": spec.command,
        "cwd": str(spec.cwd),
        "environment": controlled_environment(spec),
        "profile_events": profile_events,
        "thp_target": target_thp_mode(args.benchmark, condition),
        "host": platform.node(),
    }


def validate_resume_metadata(
    metadata_path: Path,
    args: argparse.Namespace,
    spec: BenchmarkSpec,
    condition: str,
    timeout_s: float,
    profile_events: str | None,
) -> None:
    try:
        existing = json.loads(metadata_path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as error:
        raise RuntimeError(f"Cannot validate existing metadata: {metadata_path}: {error}") from error
    expected = resume_signature(args, spec, condition, timeout_s, profile_events)
    mismatches: list[str] = []
    for key, expected_value in expected.items():
        existing_value = existing.get(key)
        if key == "timeout_s":
            try:
                matches = math.isclose(float(existing_value), float(expected_value), rel_tol=0, abs_tol=1e-9)
            except (TypeError, ValueError):
                matches = False
        else:
            matches = existing_value == expected_value
        if not matches:
            mismatches.append(f"{key}: existing={existing_value!r}, requested={expected_value!r}")
    if mismatches:
        detail = "; ".join(mismatches)
        raise RuntimeError(
            "Resume configuration differs from immutable phase metadata; preserve the data and "
            f"use a new experiment-id. {detail}"
        )


def write_metadata(
    path_base: Path,
    args: argparse.Namespace,
    spec: BenchmarkSpec,
    condition: str,
    timeout_s: float,
    profile_events: str | None,
) -> None:
    metadata: dict[str, Any] = {
        **resume_signature(args, spec, condition, timeout_s, profile_events),
        "repetitions": args.repetitions,
        "warmups": args.warmups,
        "platform": platform.platform(),
        "python": sys.version,
        "started_at": utc_now(),
        "runner": "vgo-native-sharp-compatible-v1",
    }
    path_base.with_suffix(".metadata.json").write_text(
        json.dumps(metadata, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    markdown = [
        f"# {args.benchmark} / {args.phase} metadata",
        "",
        f"- Experiment: `{args.experiment_id}`",
        f"- Condition: `{condition}`",
        f"- Repetitions: `{args.repetitions}`",
        f"- Warmups excluded: `{args.warmups}`",
        f"- Timeout per run: `{timeout_s:.3f} s`",
        f"- Started: `{metadata['started_at']}`",
        f"- Host: `{metadata['host']}`",
        f"- THP target during runs: `{metadata['thp_target'] or read_thp_mode()}`",
        "",
        "## Command",
        "",
        "```text",
        shlex.join(spec.command),
        "```",
        "",
        "## Controlled environment",
        "",
        "```json",
        json.dumps(metadata["environment"], ensure_ascii=False, indent=2),
        "```",
    ]
    path_base.with_suffix(".metadata.md").write_text("\n".join(markdown) + "\n", encoding="utf-8")


def append_log(log_path: Path, label: str, result: CommandResult) -> None:
    with log_path.open("a", encoding="utf-8") as handle:
        handle.write(f"\n===== {label} {utc_now()} =====\n")
        handle.write(f"exit_code={result.exit_code} timeout={int(result.timed_out)} ")
        handle.write(f"wall_time_s={result.wall_time_s:.9f}\n")
        handle.write("--- stdout ---\n")
        handle.write(result.stdout)
        if result.stdout and not result.stdout.endswith("\n"):
            handle.write("\n")
        handle.write("--- stderr ---\n")
        handle.write(result.stderr)
        if result.stderr and not result.stderr.endswith("\n"):
            handle.write("\n")


def row_from_result(
    args: argparse.Namespace,
    condition: str,
    repetition: int,
    result: CommandResult,
    log_path: Path,
) -> dict[str, Any]:
    metric, metric_name = app_metric(args.benchmark, result)
    row: dict[str, Any] = {field: "" for field in CSV_FIELDS}
    row.update(
        {
            "run_id": (
                f"{args.experiment_id}-{args.benchmark}-{args.phase}-"
                f"{condition}-{repetition:04d}"
            ),
            "benchmark": args.benchmark,
            "phase": args.phase,
            "condition": condition,
            "repetition": repetition,
            "timestamp": utc_now(),
            "wall_time_s": f"{result.wall_time_s:.9f}",
            "app_metric": f"{metric:.9f}",
            "app_metric_name": metric_name,
            "exit_code": result.exit_code,
            "correctness": int(benchmark_correct(args.benchmark, result)),
            "cpu_steal": f"{result.cpu_steal_pct:.6f}",
            "thp_state": read_thp_mode(),
            "timeout": int(result.timed_out),
            "log_file": str(log_path),
        }
    )
    for key, value in result.perf.items():
        if key in row and value is not None:
            row[key] = f"{value:.9g}"
    if result.perf.get("perf_running_pct") is not None:
        row["perf_running_pct"] = f"{result.perf['perf_running_pct']:.6f}"
    for key, value in result.bintime.items():
        if key in row and value is not None:
            row[key] = f"{value:.9g}"
    return row


def parse_args(argv: Iterable[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--benchmark", required=True, choices=["matmul", "7z", "lbm", "sad"])
    parser.add_argument(
        "--phase",
        required=True,
        choices=[
            "correctness",
            "pilot",
            "baseline",
            "profile_probe",
            "profile",
            "mitigated",
            "rollback",
            "blocked",
        ],
    )
    parser.add_argument("--condition", choices=["baseline", "mitigated"])
    parser.add_argument("--repetitions", required=True, type=int)
    parser.add_argument("--warmups", type=int, default=10)
    parser.add_argument("--timeout", default="auto", help="Seconds or 'auto' from pilot P99")
    parser.add_argument("--experiment-id")
    parser.add_argument("--config", type=Path)
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--dry-run", action="store_true")
    parser.add_argument("--inter-run-delay", type=float)
    args = parser.parse_args(argv)
    if args.repetitions <= 0 or args.warmups < 0:
        parser.error("repetitions must be positive and warmups non-negative")
    if args.experiment_id is None:
        args.experiment_id = datetime.now(timezone.utc).strftime("manual_%Y%m%dT%H%M%SZ")
    if not VALID_EXPERIMENT_ID.fullmatch(args.experiment_id):
        parser.error("experiment-id may contain only letters, numbers, dot, underscore and hyphen")
    return args


def main(argv: Iterable[str] | None = None) -> int:
    args = parse_args(argv)
    script_dir = Path(__file__).resolve().parent
    root = script_dir.parent
    config_path = args.config or root / "config" / "experiment.env"
    config = load_env_file(config_path)
    condition = condition_for_phase(args.phase, args.condition)
    spec = build_benchmark_spec(args.benchmark, condition, root, config)
    profile_events = perf_events_for_phase(args.benchmark, args.phase, config)
    delay_s = (
        args.inter_run_delay
        if args.inter_run_delay is not None
        else float(config.get("VGO_INTER_RUN_DELAY_SECONDS", "1"))
    )

    raw_root = root / "data" / "raw" / args.experiment_id
    phase_name = f"{args.phase}_{condition}" if args.phase in {"pilot", "blocked"} else args.phase
    benchmark_dir = raw_root / args.benchmark
    csv_path = benchmark_dir / f"{phase_name}.csv"
    metadata_base = benchmark_dir / phase_name
    log_dir = root / "logs" / args.experiment_id / args.benchmark
    log_path = log_dir / f"{phase_name}.log"

    fallback_timeout = float(config.get("VGO_DEFAULT_TIMEOUT_SECONDS", "180"))
    timeout_s = (
        timeout_from_pilot(raw_root, args.benchmark, fallback_timeout)
        if args.timeout == "auto"
        else float(args.timeout)
    )
    if timeout_s <= 0:
        raise ValueError("timeout must be positive")

    print(f"experiment={args.experiment_id}")
    print(f"benchmark={args.benchmark} phase={args.phase} condition={condition}")
    print(f"command={shlex.join(spec.command)}")
    print(f"repetitions={args.repetitions} warmups={args.warmups} timeout={timeout_s:.3f}s")
    print(f"output={csv_path}")
    if args.dry_run:
        return 0

    benchmark_dir.mkdir(parents=True, exist_ok=True)
    log_dir.mkdir(parents=True, exist_ok=True)
    if csv_path.exists() and not args.resume:
        raise FileExistsError(f"Raw data already exists; use --resume or a new experiment-id: {csv_path}")
    if csv_path.exists():
        validate_existing_csv(csv_path)
    start_repetition = existing_repetitions(csv_path) + 1 if csv_path.exists() else 1
    if start_repetition > args.repetitions:
        print("Requested repetition target is already complete.")
        return 0

    metadata_json = metadata_base.with_suffix(".metadata.json")
    metadata_markdown = metadata_base.with_suffix(".metadata.md")
    if not metadata_json.exists() and not metadata_markdown.exists():
        write_metadata(
            metadata_base,
            args,
            spec,
            condition,
            timeout_s,
            profile_events,
        )
    elif not (metadata_json.exists() and metadata_markdown.exists()):
        raise RuntimeError(
            f"Only one metadata file exists for {metadata_base}; preserve the evidence and use "
            "a new experiment-id"
        )
    else:
        validate_resume_metadata(
            metadata_json,
            args,
            spec,
            condition,
            timeout_s,
            profile_events,
        )
        print(f"metadata=preserved ({metadata_json})")

    original_thp: str | None = None
    if args.benchmark == "sad":
        original_thp = read_thp_mode()
        if original_thp not in {"always", "madvise", "never"}:
            raise RuntimeError(f"Cannot determine original THP mode: {original_thp}")
        thp_target = target_thp_mode(args.benchmark, condition)
        if thp_target is None:
            raise AssertionError("SAD must have a THP target")
        set_thp_mode(thp_target)

    try:
        for warmup in range(1, args.warmups + 1):
            result = run_once(spec, False, timeout_s, config, None)
            append_log(log_path, f"warmup-{warmup}", result)
            if not benchmark_correct(args.benchmark, result):
                raise RuntimeError(f"Warmup {warmup} failed correctness; see {log_path}")
            if delay_s > 0:
                time.sleep(delay_s)

        write_header = not csv_path.exists()
        mode = "a" if csv_path.exists() else "w"
        completed_rows: list[dict[str, Any]] = []
        with csv_path.open(mode, encoding="utf-8", newline="") as handle:
            writer = csv.DictWriter(handle, fieldnames=CSV_FIELDS)
            if write_header:
                writer.writeheader()
                handle.flush()
            for repetition in range(start_repetition, args.repetitions + 1):
                result = run_once(
                    spec,
                    args.phase in PROFILE_PHASES,
                    timeout_s,
                    config,
                    profile_events,
                )
                append_log(log_path, f"run-{repetition}", result)
                row = row_from_result(args, condition, repetition, result, log_path)
                writer.writerow(row)
                handle.flush()
                completed_rows.append(row)
                print(
                    f"[{repetition}/{args.repetitions}] wall={float(row['wall_time_s']):.6f}s "
                    f"correct={row['correctness']} steal={float(row['cpu_steal']):.3f}%",
                    flush=True,
                )
                if int(row["correctness"]) != 1:
                    raise RuntimeError(f"Run {repetition} failed correctness; raw row retained in {csv_path}")
                if args.phase == "profile":
                    missing_events = missing_requested_perf_events(row, profile_events)
                    if missing_events:
                        raise RuntimeError(
                            f"perf did not count requested events {missing_events}; the failed row was "
                            "retained. Verify PMU access and restart with a new experiment-id."
                        )
                    running = parse_number(str(row["perf_running_pct"]))
                    minimum_running = float(config.get("VGO_PERF_MIN_RUNNING_PCT", "90"))
                    if running is None or running < minimum_running:
                        raise RuntimeError(
                            f"perf running ratio is {running!r}, below {minimum_running:.1f}%; "
                            "the failed row was retained. Keep each formal event group at <=4 "
                            "events and restart with a new experiment-id."
                        )
                if delay_s > 0 and repetition < args.repetitions:
                    time.sleep(delay_s)

        if completed_rows:
            steal_values = [float(row["cpu_steal"]) for row in completed_rows]
            high_steal = sum(value > 2.0 for value in steal_values)
            high_rate = high_steal / len(steal_values)
            print(
                f"completed={len(completed_rows)} median_steal={statistics.median(steal_values):.3f}% "
                f"high_steal_rate={high_rate:.3%}"
            )
            if high_rate > 0.05:
                print("WARNING: more than 5% of runs have CPU steal >2%; rerun this phase.", file=sys.stderr)
                return 4
            if args.phase in PROFILE_PHASES:
                missing_events = sorted(
                    {
                        event
                        for row in completed_rows
                        for event in missing_requested_perf_events(row, profile_events)
                    }
                )
                if missing_events:
                    print(
                        f"NOTICE: perf did not count these requested events: {missing_events}",
                        file=sys.stderr,
                    )
                perf_percentages = [
                    value
                    for row in completed_rows
                    if (value := parse_number(str(row["perf_running_pct"]))) is not None
                ]
                if perf_percentages:
                    minimum_running = min(perf_percentages)
                    print(f"minimum_perf_running_pct={minimum_running:.3f}%")
                    if args.phase == "profile_probe" and minimum_running < float(
                        config.get("VGO_PERF_MIN_RUNNING_PCT", "90")
                    ):
                        print(
                            "NOTICE: the full-event probe was multiplexed; formal profile uses "
                            "a focused <=4-event group.",
                            file=sys.stderr,
                        )
                else:
                    print("WARNING: perf did not report a running percentage.", file=sys.stderr)
        return 0
    finally:
        if original_thp is not None and read_thp_mode() != original_thp:
            set_thp_mode(original_thp)


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except KeyboardInterrupt:
        print("Interrupted; completed raw rows were preserved.", file=sys.stderr)
        raise SystemExit(130)
    except Exception as error:
        print(f"ERROR: {error}", file=sys.stderr)
        raise SystemExit(1)
