#!/usr/bin/env bash
set -Eeuo pipefail
export LC_ALL=C

SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd -P)"
ROOT_DIR="$(cd -- "$SCRIPT_DIR/.." && pwd -P)"
CONFIG_FILE="$ROOT_DIR/config/experiment.env"
METADATA_DIR="$ROOT_DIR/data/metadata"
PHASE0_CHECK="$SCRIPT_DIR/check_environment.sh"
SHARP_COMMIT="d22926f541f1f3cfbd2e9d805fd087b4607e6712"

log() { printf '[validate] %s\n' "$*"; }
die() { printf '[validate] ERROR: %s\n' "$*" >&2; exit 1; }

[[ -f "$CONFIG_FILE" ]] || die "Missing config: $CONFIG_FILE"
# shellcheck disable=SC1090
set -a
source "$CONFIG_FILE"
set +a

resolve_path() {
  case "$1" in
    /*) printf '%s\n' "$1" ;;
    *) printf '%s/%s\n' "$ROOT_DIR" "$1" ;;
  esac
}

PARBOIL_ROOT="$(resolve_path "$VGO_PARBOIL_ROOT")"
SHARP_ROOT="$(resolve_path "$VGO_SHARP_ROOT")"
THP_FILE="/sys/kernel/mm/transparent_hugepage/enabled"
mkdir -p "$METADATA_DIR"

timestamp="$(date -u +%Y%m%dT%H%M%SZ)"
snapshot="$METADATA_DIR/machine_snapshot_${timestamp}.md"
gate_file="$METADATA_DIR/gate.env"
perf_sw_log="$(mktemp)"
perf_hw_log="$(mktemp)"
mpstat_log="$(mktemp)"
initial_thp=""
cleanup() {
  if [[ -n "$initial_thp" && -r "$THP_FILE" ]] && [[ "$(grep -o '\[[^]]*\]' "$THP_FILE" | tr -d '[]' || true)" != "$initial_thp" ]]; then
    printf '%s\n' "$initial_thp" | sudo -n tee "$THP_FILE" >/dev/null || true
  fi
  rm -f -- "$perf_sw_log" "$perf_hw_log" "$mpstat_log"
}
trap cleanup EXIT

# Phase 0 itself is read-only and writes the required per-event JSON evidence.
# This stricter G2 gate below runs only after dependencies have been prepared.
bash "$PHASE0_CHECK"

cpu_count="$(nproc)"
memory_kib="$(awk '/MemTotal:/ {print $2}' /proc/meminfo)"
memory_gib="$((memory_kib / 1024 / 1024))"
disk_free_gib="$(df -Pk "$ROOT_DIR" | awk 'NR==2 {print int($4/1024/1024)}')"

cpu_ok=0
memory_ok=0
disk_ok=0
sudo_ok=0
perf_software_ok=0
perf_hardware_ok=0
thp_readable=0
thp_writable=0
benchmarks_ok=0
sharp_ok=0
matmul_ok=0
steal_ok=0

(( cpu_count >= 8 )) && cpu_ok=1
(( memory_gib >= 14 )) && memory_ok=1
(( disk_free_gib >= 20 )) && disk_ok=1

log "Checking passwordless sudo without requiring a TTY"
if sudo -n true; then
  sudo_ok=1
fi

if [[ -r "$THP_FILE" ]]; then
  thp_readable=1
fi
if (( sudo_ok == 1 && thp_readable == 1 )); then
  initial_thp="$(grep -o '\[[^]]*\]' "$THP_FILE" | tr -d '[]' || true)"
  if [[ "$initial_thp" =~ ^(always|madvise|never)$ ]] && \
     printf '%s\n' "$initial_thp" | sudo -n tee "$THP_FILE" >/dev/null && \
     [[ "$(grep -o '\[[^]]*\]' "$THP_FILE" | tr -d '[]' || true)" == "$initial_thp" ]]; then
    thp_writable=1
  fi
fi

if (( sudo_ok == 1 )) && command -v perf >/dev/null 2>&1; then
  if sudo -n perf stat \
      -e context-switches,cpu-migrations,page-faults \
      -- sleep 1 >/dev/null 2>"$perf_sw_log" && \
      ! grep -Eqi 'not supported|not counted|no permission|access denied' "$perf_sw_log"; then
    perf_software_ok=1
  fi

  if sudo -n perf stat \
      -e cycles,instructions,cache-misses,dTLB-load-misses \
      -- bash -c 'value=0; for ((i=0; i<3000000; i++)); do value=$((value+i)); done; : "$value"' \
      >/dev/null 2>"$perf_hw_log" && \
      ! grep -Eqi 'not supported|not counted|no permission|access denied' "$perf_hw_log"; then
    perf_hardware_ok=1
  fi
else
  printf 'perf or passwordless sudo is unavailable\n' > "$perf_sw_log"
  printf 'perf or passwordless sudo is unavailable\n' > "$perf_hw_log"
fi

if command -v mpstat >/dev/null 2>&1; then
  mpstat 1 5 > "$mpstat_log" || true
fi
average_steal="$(awk '/^Average:/ && $2 == "all" {print $(NF-3)}' "$mpstat_log" | tail -n 1)"
average_steal="${average_steal:-NA}"
if [[ "$average_steal" =~ ^[0-9]+([.][0-9]+)?$ ]] && \
   awk -v steal="$average_steal" 'BEGIN { exit !(steal <= 2.0) }'; then
  steal_ok=1
fi

if command -v 7z >/dev/null 2>&1 && \
   command -v setpriv >/dev/null 2>&1 && \
   [[ -f "$PARBOIL_ROOT/.vgo-ready" ]] && \
   [[ -x "$PARBOIL_ROOT/parboil" ]]; then
  benchmarks_ok=1
fi

if [[ -x "$ROOT_DIR/.venv/bin/python" ]] && \
   "$ROOT_DIR/.venv/bin/python" -c 'import numpy' >/dev/null 2>&1; then
  matmul_ok=1
fi

sharp_commit="$(git -c safe.directory="$SHARP_ROOT" -C "$SHARP_ROOT" rev-parse HEAD 2>/dev/null || true)"
if [[ -d "$SHARP_ROOT/.git" ]] && [[ "$sharp_commit" == "$SHARP_COMMIT" ]]; then
  sharp_ok=1
fi

thp_state="NA"
if (( thp_readable == 1 )); then
  thp_state="$(grep -o '\[[^]]*\]' "$THP_FILE" | tr -d '[]' || true)"
  thp_state="${thp_state:-unknown}"
fi

numa_nodes="$(lscpu -p=NODE 2>/dev/null | grep -v '^#' | sort -u | wc -l | tr -d ' ')"
numa_nodes="${numa_nodes:-0}"

full_go=0
partial_go=0
if (( cpu_ok && memory_ok && disk_ok && sudo_ok && perf_software_ok && \
      perf_hardware_ok && thp_readable && thp_writable && benchmarks_ok && matmul_ok && sharp_ok && \
      steal_ok )); then
  full_go=1
  partial_go=1
elif (( cpu_ok && memory_ok && disk_ok && sudo_ok && perf_software_ok && \
        benchmarks_ok && matmul_ok && sharp_ok && steal_ok )); then
  partial_go=1
fi

cat > "$gate_file" <<EOF
VGO_GATE_TIMESTAMP=$timestamp
VGO_FULL_GO=$full_go
VGO_PARTIAL_GO=$partial_go
VGO_CPU_OK=$cpu_ok
VGO_MEMORY_OK=$memory_ok
VGO_DISK_OK=$disk_ok
VGO_SUDO_OK=$sudo_ok
VGO_PERF_SOFTWARE_OK=$perf_software_ok
VGO_PERF_HARDWARE_OK=$perf_hardware_ok
VGO_THP_READABLE=$thp_readable
VGO_THP_WRITABLE=$thp_writable
VGO_BENCHMARKS_OK=$benchmarks_ok
VGO_MATMUL_OK=$matmul_ok
VGO_SHARP_OK=$sharp_ok
VGO_STEAL_OK=$steal_ok
VGO_CPU_COUNT=$cpu_count
VGO_MEMORY_GIB=$memory_gib
VGO_DISK_FREE_GIB=$disk_free_gib
VGO_NUMA_NODES=$numa_nodes
VGO_AVERAGE_STEAL_PCT=$average_steal
EOF

{
  printf '# VGO machine snapshot\n\n'
  printf -- '- Captured (UTC): `%s`\n' "$timestamp"
  printf -- '- Full three-case gate: `%s`\n' "$full_go"
  printf -- '- CPU-only partial gate: `%s`\n' "$partial_go"
  printf -- '- Visible CPUs: `%s`\n' "$cpu_count"
  printf -- '- Memory: `%s GiB`\n' "$memory_gib"
  printf -- '- Free workspace disk: `%s GiB`\n' "$disk_free_gib"
  printf -- '- Visible NUMA nodes: `%s`\n' "$numa_nodes"
  printf -- '- THP active mode: `%s`\n' "$thp_state"
  printf -- '- Average CPU steal during 5-second sample: `%s%%`\n\n' "$average_steal"

  printf '## Gate results\n\n'
  printf '| Check | Result |\n|---|---:|\n'
  printf '| >= 8 vCPU | %s |\n' "$cpu_ok"
  printf '| >= 14 GiB RAM | %s |\n' "$memory_ok"
  printf '| >= 20 GiB free disk | %s |\n' "$disk_ok"
  printf '| sudo | %s |\n' "$sudo_ok"
  printf '| perf software events | %s |\n' "$perf_software_ok"
  printf '| perf hardware events, including dTLB | %s |\n' "$perf_hardware_ok"
  printf '| THP readable | %s |\n' "$thp_readable"
  printf '| THP writable | %s |\n' "$thp_writable"
  printf '| 7-Zip and Parboil prepared | %s |\n' "$benchmarks_ok"
  printf '| NumPy Matmul prepared | %s |\n' "$matmul_ok"
  printf '| SHARP v3.0.0 exact commit | %s |\n' "$sharp_ok"
  printf '| 5-second average CPU steal <= 2%% | %s |\n\n' "$steal_ok"

  printf '## lscpu\n\n```text\n'
  lscpu 2>&1 || true
  printf '```\n\n## numactl --hardware\n\n```text\n'
  numactl --hardware 2>&1 || true
  printf '```\n\n## Memory and disk\n\n```text\n'
  free -h 2>&1 || true
  df -h "$ROOT_DIR" 2>&1 || true
  printf '```\n\n## perf software-event test\n\n```text\n'
  cat "$perf_sw_log"
  printf '```\n\n## perf hardware-event test\n\n```text\n'
  cat "$perf_hw_log"
  printf '```\n\n## mpstat sample\n\n```text\n'
  cat "$mpstat_log"
  printf '```\n\n## Kernel controls\n\n```text\n'
  sysctl kernel.perf_event_paranoid 2>&1 || true
  [[ -r "$THP_FILE" ]] && cat "$THP_FILE" || true
  printf '```\n'
} > "$snapshot"

cp -- "$snapshot" "$METADATA_DIR/machine_snapshot.md"
log "Snapshot: $snapshot"
log "Gate file: $gate_file"

if (( full_go == 1 )); then
  log "GO: all three CPU cases can proceed."
  exit 0
fi
if (( partial_go == 1 )); then
  log "PARTIAL GO: 7-Zip/LBM can proceed, but SAD factor attribution is incomplete."
  exit 2
fi
log "NO-GO: release or replace the instance before formal testing."
exit 3
